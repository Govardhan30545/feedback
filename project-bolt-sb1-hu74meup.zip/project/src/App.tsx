import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import FeedbackList from './pages/FeedbackList';
import FeedbackDetail from './pages/FeedbackDetail';
import FeedbackForm from './pages/FeedbackForm';
import Settings from './pages/Settings';
import Layout from './components/Layout';
import { FeedbackProvider } from './context/FeedbackContext';
import './App.css';

function App() {
  return (
    <FeedbackProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="feedback" element={<FeedbackList />} />
            <Route path="feedback/:id" element={<FeedbackDetail />} />
            <Route path="submit" element={<FeedbackForm />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </Router>
    </FeedbackProvider>
  );
}

export default App;