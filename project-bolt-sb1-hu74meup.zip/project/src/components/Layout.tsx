import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Send, 
  Settings, 
  Menu, 
  X, 
  Bell
} from 'lucide-react';

const Layout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const location = useLocation();
  
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Close sidebar on route change on mobile
  React.useEffect(() => {
    if (isSidebarOpen) {
      setIsSidebarOpen(false);
    }
  }, [location.pathname]);
  
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-900 bg-opacity-50 z-20 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 left-0 z-30 w-64 transition-transform transform bg-white border-r border-gray-200 lg:translate-x-0 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:static lg:w-64 flex-shrink-0`}
      >
        <div className="h-full flex flex-col">
          {/* Sidebar header */}
          <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200">
            <Link to="/" className="flex items-center space-x-2">
              <MessageSquare className="w-6 h-6 text-primary-600" />
              <span className="text-xl font-semibold text-gray-900">FeedbackHub</span>
            </Link>
            <button 
              className="lg:hidden"
              onClick={toggleSidebar}
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          {/* Sidebar content */}
          <nav className="flex-1 overflow-auto py-4 px-3">
            <ul className="space-y-1">
              <li>
                <Link
                  to="/"
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    location.pathname === '/' 
                      ? 'text-primary-700 bg-primary-50' 
                      : 'text-gray-700 hover:text-primary-700 hover:bg-gray-100'
                  }`}
                >
                  <LayoutDashboard className="mr-3 h-5 w-5" />
                  Dashboard
                </Link>
              </li>
              <li>
                <Link
                  to="/feedback"
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    location.pathname.startsWith('/feedback') && location.pathname !== '/feedback/new' 
                      ? 'text-primary-700 bg-primary-50' 
                      : 'text-gray-700 hover:text-primary-700 hover:bg-gray-100'
                  }`}
                >
                  <MessageSquare className="mr-3 h-5 w-5" />
                  Feedbacks
                </Link>
              </li>
              <li>
                <Link
                  to="/submit"
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    location.pathname === '/submit' 
                      ? 'text-primary-700 bg-primary-50' 
                      : 'text-gray-700 hover:text-primary-700 hover:bg-gray-100'
                  }`}
                >
                  <Send className="mr-3 h-5 w-5" />
                  Submit Feedback
                </Link>
              </li>
              <li>
                <Link
                  to="/settings"
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    location.pathname === '/settings' 
                      ? 'text-primary-700 bg-primary-50' 
                      : 'text-gray-700 hover:text-primary-700 hover:bg-gray-100'
                  }`}
                >
                  <Settings className="mr-3 h-5 w-5" />
                  Settings
                </Link>
              </li>
            </ul>
          </nav>
          
          {/* Sidebar footer */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center">
              <img 
                src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="User" 
                className="w-8 h-8 rounded-full mr-3"
              />
              <div>
                <p className="text-sm font-medium text-gray-900">John Doe</p>
                <p className="text-xs text-gray-500">Admin</p>
              </div>
            </div>
          </div>
        </div>
      </aside>
      
      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 flex items-center justify-between border-b border-gray-200 bg-white px-4 lg:px-6">
          <div className="flex items-center">
            <button
              onClick={toggleSidebar}
              className="text-gray-500 focus:outline-none focus:text-gray-700 lg:hidden"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="ml-4 lg:ml-0">
              <h1 className="text-lg font-semibold text-gray-900">
                {location.pathname === '/' && 'Dashboard'}
                {location.pathname === '/feedback' && 'Feedback Management'}
                {location.pathname.startsWith('/feedback/') && 'Feedback Details'}
                {location.pathname === '/submit' && 'Submit Feedback'}
                {location.pathname === '/settings' && 'Settings'}
              </h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="text-gray-500 hover:text-gray-700 focus:outline-none">
              <Bell className="h-5 w-5" />
            </button>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="User" 
                className="w-8 h-8 rounded-full border border-gray-300"
              />
            </div>
          </div>
        </header>
        
        {/* Main content area */}
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          <Outlet />
        </main>
        
        {/* Footer */}
        <footer className="border-t border-gray-200 py-4 px-6">
          <p className="text-sm text-gray-600 text-center">
            &copy; 2025 FeedbackHub. All rights reserved.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default Layout;