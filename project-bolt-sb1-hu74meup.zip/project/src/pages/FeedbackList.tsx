import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useFeedback } from '../context/FeedbackContext';
import { FeedbackStatus, FeedbackPriority, FeedbackSource, Feedback } from '../types';
import { 
  Search, 
  Filter,
  Download, 
  Sliders,
  Eye
} from 'lucide-react';

const FeedbackList: React.FC = () => {
  const { feedbacks, isLoading } = useFeedback();
  
  // Filtering state
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<FeedbackStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<FeedbackPriority | 'all'>('all');
  const [sourceFilter, setSourceFilter] = useState<FeedbackSource | 'all'>('all');
  
  // Sorting state
  const [sortField, setSortField] = useState<keyof Feedback>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Filters and sort the feedback list
  const filteredFeedbacks = useMemo(() => {
    return feedbacks
      .filter(feedback => {
        const matchesSearch = 
          feedback.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          feedback.description.toLowerCase().includes(searchTerm.toLowerCase());
          
        const matchesStatus = statusFilter === 'all' || feedback.status === statusFilter;
        const matchesPriority = priorityFilter === 'all' || feedback.priority === priorityFilter;
        const matchesSource = sourceFilter === 'all' || feedback.source === sourceFilter;
        
        return matchesSearch && matchesStatus && matchesPriority && matchesSource;
      })
      .sort((a, b) => {
        if (sortField === 'createdAt') {
          return sortDirection === 'asc' 
            ? a.createdAt.getTime() - b.createdAt.getTime()
            : b.createdAt.getTime() - a.createdAt.getTime();
        }
        
        const aValue = String(a[sortField]);
        const bValue = String(b[sortField]);
        
        return sortDirection === 'asc'
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      });
  }, [feedbacks, searchTerm, statusFilter, priorityFilter, sourceFilter, sortField, sortDirection]);
  
  // Function to handle sort change
  const handleSort = (field: keyof Feedback) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };
  
  // Export feedbacks to CSV
  const exportToCsv = () => {
    const headers = ['Title', 'Description', 'Status', 'Priority', 'Source', 'Category', 'Created At', 'Submitter'];
    
    const csvContent = [
      headers.join(','),
      ...filteredFeedbacks.map(feedback => [
        `"${feedback.title.replace(/"/g, '""')}"`,
        `"${feedback.description.replace(/"/g, '""')}"`,
        feedback.status,
        feedback.priority,
        feedback.source,
        feedback.category,
        feedback.createdAt.toISOString(),
        feedback.submitterEmail
      ].join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'feedbacks.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Reset all filters
  const resetFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setPriorityFilter('all');
    setSourceFilter('all');
    setSortField('createdAt');
    setSortDirection('desc');
  };
  
  // Loading state
  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="w-12 h-12 rounded-full bg-primary-200 mb-3"></div>
          <div className="h-4 w-24 bg-primary-100 rounded"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Filter and search bar */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Search feedbacks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex space-x-2">
            <div className="relative">
              <select
                className="block w-full pl-3 pr-8 py-2 text-base border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as FeedbackStatus | 'all')}
              >
                <option value="all">All Status</option>
                {Object.values(FeedbackStatus).map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                <Filter className="h-4 w-4 text-gray-400" />
              </div>
            </div>
            
            <div className="relative">
              <select
                className="block w-full pl-3 pr-8 py-2 text-base border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value as FeedbackPriority | 'all')}
              >
                <option value="all">All Priorities</option>
                {Object.values(FeedbackPriority).map((priority) => (
                  <option key={priority} value={priority}>{priority}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                <Sliders className="h-4 w-4 text-gray-400" />
              </div>
            </div>
            
            <div className="relative">
              <select
                className="block w-full pl-3 pr-8 py-2 text-base border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
                value={sourceFilter}
                onChange={(e) => setSourceFilter(e.target.value as FeedbackSource | 'all')}
              >
                <option value="all">All Sources</option>
                {Object.values(FeedbackSource).map((source) => (
                  <option key={source} value={source}>{source}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                <Filter className="h-4 w-4 text-gray-400" />
              </div>
            </div>
            
            <button
              className="px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              onClick={resetFilters}
            >
              Reset
            </button>
            
            <button
              className="px-3 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              onClick={exportToCsv}
            >
              <Download className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Results */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('title')}
                >
                  <div className="flex items-center">
                    Title
                    {sortField === 'title' && (
                      <span className="ml-1">
                        {sortDirection === 'asc' ? '↑' : '↓'}
                      </span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center">
                    Status
                    {sortField === 'status' && (
                      <span className="ml-1">
                        {sortDirection === 'asc' ? '↑' : '↓'}
                      </span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('priority')}
                >
                  <div className="flex items-center">
                    Priority
                    {sortField === 'priority' && (
                      <span className="ml-1">
                        {sortDirection === 'asc' ? '↑' : '↓'}
                      </span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('source')}
                >
                  <div className="flex items-center">
                    Source
                    {sortField === 'source' && (
                      <span className="ml-1">
                        {sortDirection === 'asc' ? '↑' : '↓'}
                      </span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('createdAt')}
                >
                  <div className="flex items-center">
                    Date
                    {sortField === 'createdAt' && (
                      <span className="ml-1">
                        {sortDirection === 'asc' ? '↑' : '↓'}
                      </span>
                    )}
                  </div>
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredFeedbacks.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                    No feedback found matching your criteria
                  </td>
                </tr>
              ) : (
                filteredFeedbacks.map((feedback) => (
                  <tr key={feedback.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{feedback.title}</div>
                      <div className="text-sm text-gray-500 truncate max-w-sm">
                        {feedback.description.length > 100 
                          ? `${feedback.description.substring(0, 100)}...` 
                          : feedback.description}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span 
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          feedback.status === FeedbackStatus.NEW ? 'bg-blue-100 text-blue-800' :
                          feedback.status === FeedbackStatus.IN_PROGRESS ? 'bg-purple-100 text-purple-800' :
                          feedback.status === FeedbackStatus.PLANNED ? 'bg-cyan-100 text-cyan-800' :
                          feedback.status === FeedbackStatus.COMPLETED ? 'bg-success-100 text-success-800' :
                          feedback.status === FeedbackStatus.REJECTED ? 'bg-gray-100 text-gray-800' :
                          'bg-error-100 text-error-800'
                        }`}
                      >
                        {feedback.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span 
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          feedback.priority === FeedbackPriority.CRITICAL ? 'bg-error-100 text-error-800' :
                          feedback.priority === FeedbackPriority.HIGH ? 'bg-orange-100 text-orange-800' :
                          feedback.priority === FeedbackPriority.MEDIUM ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}
                      >
                        {feedback.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {feedback.source}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {feedback.createdAt.toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Link
                        to={`/feedback/${feedback.id}`}
                        className="text-primary-600 hover:text-primary-900 flex items-center justify-end"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination placeholder */}
        <div className="flex items-center justify-between border-t border-gray-200 px-4 py-3 sm:px-6">
          <div className="flex items-center">
            <p className="text-sm text-gray-700">
              Showing <span className="font-medium">1</span> to{' '}
              <span className="font-medium">{Math.min(filteredFeedbacks.length, 10)}</span> of{' '}
              <span className="font-medium">{filteredFeedbacks.length}</span> results
            </p>
          </div>
          <div className="flex justify-between">
            <button
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 mr-3"
              disabled
            >
              Previous
            </button>
            <button
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              disabled={filteredFeedbacks.length <= 10}
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedbackList;