import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useFeedback } from '../context/FeedbackContext';
import { FeedbackStatus, FeedbackPriority, Comment } from '../types';
import { 
  Clock, 
  ArrowLeft,
  MessageSquare,
  Send,
  User,
  AlertTriangle,
  CheckCircle,
  Edit,
  Trash,
  Share2,
  Mail
} from 'lucide-react';

const FeedbackDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getFeedbackById, updateFeedback, deleteFeedback } = useFeedback();
  
  const feedback = getFeedbackById(id || '');
  
  const [newComment, setNewComment] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedStatus, setEditedStatus] = useState<FeedbackStatus>(
    feedback?.status || FeedbackStatus.NEW
  );
  const [editedPriority, setEditedPriority] = useState<FeedbackPriority>(
    feedback?.priority || FeedbackPriority.MEDIUM
  );
  const [editedAssignee, setEditedAssignee] = useState<string>(
    feedback?.assignedTo || ''
  );
  
  // Update state when feedback changes
  useEffect(() => {
    if (feedback) {
      setEditedStatus(feedback.status);
      setEditedPriority(feedback.priority);
      setEditedAssignee(feedback.assignedTo || '');
    }
  }, [feedback]);
  
  // Handle adding a new comment
  const handleAddComment = () => {
    if (!feedback || !newComment.trim()) return;
    
    const comment: Comment = {
      id: Date.now().toString(),
      text: newComment,
      author: 'john.doe@company.com', // In a real app, this would be the logged-in user
      createdAt: new Date()
    };
    
    const updatedComments = [...feedback.comments, comment];
    
    updateFeedback(feedback.id, { comments: updatedComments });
    setNewComment('');
  };
  
  // Handle saving edits
  const handleSaveChanges = () => {
    if (!feedback) return;
    
    updateFeedback(feedback.id, {
      status: editedStatus,
      priority: editedPriority,
      assignedTo: editedAssignee || null
    });
    
    setIsEditing(false);
  };
  
  // Handle deleting feedback
  const handleDelete = () => {
    if (!feedback) return;
    
    if (window.confirm('Are you sure you want to delete this feedback?')) {
      deleteFeedback(feedback.id);
      navigate('/feedback');
    }
  };
  
  // If feedback not found
  if (!feedback) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <div className="text-gray-500 mb-4">
          <AlertTriangle className="h-12 w-12 mx-auto" />
        </div>
        <h2 className="text-xl font-bold text-gray-700 mb-2">Feedback Not Found</h2>
        <p className="text-gray-500 mb-4">The feedback you're looking for doesn't exist or has been removed.</p>
        <button
          onClick={() => navigate('/feedback')}
          className="flex items-center justify-center text-primary-600 hover:text-primary-800"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Feedback List
        </button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Back button and actions */}
      <div className="flex justify-between items-center">
        <button
          onClick={() => navigate('/feedback')}
          className="flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to list
        </button>
        
        <div className="flex space-x-3">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary-500"
          >
            <Edit className="h-4 w-4 mr-1" />
            {isEditing ? 'Cancel Edit' : 'Edit'}
          </button>
          
          <button
            onClick={handleDelete}
            className="flex items-center px-3 py-2 border border-error-300 rounded-md text-sm font-medium text-error-700 bg-white hover:bg-error-50 focus:outline-none focus:ring-1 focus:ring-error-500"
          >
            <Trash className="h-4 w-4 mr-1" />
            Delete
          </button>
          
          <button
            className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary-500"
          >
            <Share2 className="h-4 w-4 mr-1" />
            Share
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="md:col-span-2 space-y-6">
          {/* Feedback header */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{feedback.title}</h1>
              <div>
                <span 
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    feedback.status === FeedbackStatus.NEW ? 'bg-blue-100 text-blue-800' :
                    feedback.status === FeedbackStatus.IN_PROGRESS ? 'bg-purple-100 text-purple-800' :
                    feedback.status === FeedbackStatus.PLANNED ? 'bg-cyan-100 text-cyan-800' :
                    feedback.status === FeedbackStatus.COMPLETED ? 'bg-success-100 text-success-800' :
                    feedback.status === FeedbackStatus.REJECTED ? 'bg-gray-100 text-gray-800' :
                    'bg-error-100 text-error-800'
                  }`}
                >
                  {feedback.status}
                </span>
              </div>
            </div>
            
            <div className="flex items-center text-sm text-gray-500 mt-2 mb-4">
              <Clock className="h-4 w-4 mr-1" />
              Submitted on {feedback.createdAt.toLocaleDateString()} at {feedback.createdAt.toLocaleTimeString()}
            </div>
            
            <div className="prose max-w-none text-gray-700">
              <p className="whitespace-pre-line">{feedback.description}</p>
            </div>
            
            <div className="flex flex-wrap gap-2 mt-6">
              <span 
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800`}
              >
                {feedback.category}
              </span>
              <span 
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  feedback.priority === FeedbackPriority.CRITICAL ? 'bg-error-100 text-error-800' :
                  feedback.priority === FeedbackPriority.HIGH ? 'bg-orange-100 text-orange-800' :
                  feedback.priority === FeedbackPriority.MEDIUM ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'
                }`}
              >
                {feedback.priority} Priority
              </span>
              <span 
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800`}
              >
                {feedback.source}
              </span>
            </div>
          </div>
          
          {/* Comments section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center mb-6">
              <MessageSquare className="h-5 w-5 text-gray-500 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">Comments ({feedback.comments.length})</h2>
            </div>
            
            {feedback.comments.length === 0 ? (
              <div className="text-center py-6 text-gray-500">
                <p>No comments yet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {feedback.comments.map((comment) => (
                  <div key={comment.id} className="flex space-x-3 p-4 bg-gray-50 rounded-lg">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700">
                        <User className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-gray-900">
                          {comment.author}
                        </p>
                        <p className="text-xs text-gray-500">
                          {comment.createdAt.toLocaleDateString()} {comment.createdAt.toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="mt-1 text-sm text-gray-700 whitespace-pre-line">
                        {comment.text}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Add comment */}
            <div className="mt-6">
              <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
                Add a comment
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <textarea
                  rows={3}
                  className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                  placeholder="Type your comment here..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                />
              </div>
              <div className="mt-3 flex justify-end">
                <button
                  type="button"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  onClick={handleAddComment}
                  disabled={!newComment.trim()}
                >
                  <Send className="h-4 w-4 mr-1" />
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status and details */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Details</h3>
            
            {isEditing ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={editedStatus}
                    onChange={(e) => setEditedStatus(e.target.value as FeedbackStatus)}
                  >
                    {Object.values(FeedbackStatus).map((status) => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Priority
                  </label>
                  <select
                    className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={editedPriority}
                    onChange={(e) => setEditedPriority(e.target.value as FeedbackPriority)}
                  >
                    {Object.values(FeedbackPriority).map((priority) => (
                      <option key={priority} value={priority}>{priority}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Assign To
                  </label>
                  <input
                    type="email"
                    className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    placeholder="Email address"
                    value={editedAssignee}
                    onChange={(e) => setEditedAssignee(e.target.value)}
                  />
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    onClick={handleSaveChanges}
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <dl className="space-y-3">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Status</dt>
                  <dd className="mt-1 text-sm text-gray-900">
                    <span 
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        feedback.status === FeedbackStatus.NEW ? 'bg-blue-100 text-blue-800' :
                        feedback.status === FeedbackStatus.IN_PROGRESS ? 'bg-purple-100 text-purple-800' :
                        feedback.status === FeedbackStatus.PLANNED ? 'bg-cyan-100 text-cyan-800' :
                        feedback.status === FeedbackStatus.COMPLETED ? 'bg-success-100 text-success-800' :
                        feedback.status === FeedbackStatus.REJECTED ? 'bg-gray-100 text-gray-800' :
                        'bg-error-100 text-error-800'
                      }`}
                    >
                      {feedback.status}
                    </span>
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Priority</dt>
                  <dd className="mt-1 text-sm text-gray-900">
                    <span 
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        feedback.priority === FeedbackPriority.CRITICAL ? 'bg-error-100 text-error-800' :
                        feedback.priority === FeedbackPriority.HIGH ? 'bg-orange-100 text-orange-800' :
                        feedback.priority === FeedbackPriority.MEDIUM ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}
                    >
                      {feedback.priority}
                    </span>
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Category</dt>
                  <dd className="mt-1 text-sm text-gray-900">{feedback.category}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Source</dt>
                  <dd className="mt-1 text-sm text-gray-900">{feedback.source}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Submitted By</dt>
                  <dd className="mt-1 text-sm text-gray-900">{feedback.submitterEmail}</dd>
                </div>
              </dl>
            )}
          </div>
          
          {/* Assigned to */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Assignment</h3>
            
            {feedback.assignedTo ? (
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                    <User className="h-5 w-5" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">
                    {feedback.assignedTo}
                  </p>
                  <button
                    type="button"
                    className="mt-1 text-xs text-primary-600 hover:text-primary-800"
                    onClick={() => setIsEditing(true)}
                  >
                    Reassign
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-3">
                <p className="text-sm text-gray-500">No one assigned</p>
                <button
                  type="button"
                  className="mt-2 inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  onClick={() => setIsEditing(true)}
                >
                  Assign Now
                </button>
              </div>
            )}
          </div>
          
          {/* Actions */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Actions</h3>
            
            <div className="space-y-3">
              <button
                type="button"
                className="w-full inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                <Mail className="mr-2 h-4 w-4 text-gray-500" />
                Send Email
              </button>
              <button
                type="button"
                className="w-full inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                <Share2 className="mr-2 h-4 w-4 text-gray-500" />
                Share Feedback
              </button>
              {feedback.status !== FeedbackStatus.COMPLETED && (
                <button
                  type="button"
                  className="w-full inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-success-600 hover:bg-success-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-success-500"
                  onClick={() => {
                    updateFeedback(feedback.id, { status: FeedbackStatus.COMPLETED });
                  }}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Mark as Completed
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedbackDetail;