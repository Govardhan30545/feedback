import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFeedback } from '../context/FeedbackContext';
import { FeedbackPriority, FeedbackSource } from '../types';
import { 
  Send, 
  AlertTriangle,
  CheckCircle 
} from 'lucide-react';

const FeedbackForm: React.FC = () => {
  const navigate = useNavigate();
  const { addFeedback } = useFeedback();
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Feature Request');
  const [source, setSource] = useState<FeedbackSource>(FeedbackSource.CUSTOMER);
  const [priority, setPriority] = useState<FeedbackPriority>(FeedbackPriority.MEDIUM);
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Category options
  const categoryOptions = [
    'Feature Request',
    'Bug Report',
    'UI/UX',
    'Performance',
    'Documentation',
    'Security',
    'Other'
  ];
  
  // Form validation
  const validateForm = () => {
    if (!title.trim()) {
      setError('Title is required');
      return false;
    }
    
    if (!description.trim()) {
      setError('Description is required');
      return false;
    }
    
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Valid email is required');
      return false;
    }
    
    setError(null);
    return true;
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      addFeedback({
        title,
        description,
        category,
        source,
        priority,
        submitterEmail: email,
        assignedTo: null,
      });
      
      setSuccess('Feedback submitted successfully!');
      
      // Reset form
      setTitle('');
      setDescription('');
      setCategory('Feature Request');
      setSource(FeedbackSource.CUSTOMER);
      setPriority(FeedbackPriority.MEDIUM);
      setEmail('');
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate('/feedback');
      }, 2000);
    } catch (err) {
      setError('Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Submit Feedback</h2>
          <p className="mt-1 text-sm text-gray-600">
            Share your thoughts, report issues, or suggest improvements
          </p>
        </div>
        
        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6">
          {/* Error message */}
          {error && (
            <div className="mb-6 p-4 rounded-md bg-error-50 border border-error-200">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-5 w-5 text-error-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-error-700">{error}</p>
                </div>
              </div>
            </div>
          )}
          
          {/* Success message */}
          {success && (
            <div className="mb-6 p-4 rounded-md bg-success-50 border border-success-200">
              <div className="flex">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-5 w-5 text-success-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-success-700">{success}</p>
                </div>
              </div>
            </div>
          )}
          
          <div className="space-y-6">
            {/* Title */}
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Title <span className="text-error-500">*</span>
              </label>
              <div className="mt-1">
                <input
                  type="text"
                  id="title"
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="Brief description of the feedback"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
            </div>
            
            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                Description <span className="text-error-500">*</span>
              </label>
              <div className="mt-1">
                <textarea
                  id="description"
                  rows={5}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="Provide details about your feedback..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Be specific and provide examples if possible.
              </p>
            </div>
            
            {/* Category and Source */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                  Category
                </label>
                <div className="mt-1">
                  <select
                    id="category"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    {categoryOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-700">
                  Source
                </label>
                <div className="mt-1">
                  <select
                    id="source"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    value={source}
                    onChange={(e) => setSource(e.target.value as FeedbackSource)}
                  >
                    {Object.values(FeedbackSource).map((source) => (
                      <option key={source} value={source}>
                        {source}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            
            {/* Priority */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority
              </label>
              <div className="flex flex-wrap gap-4">
                {Object.values(FeedbackPriority).map((p) => (
                  <label
                    key={p}
                    className={`flex items-center px-4 py-2 rounded-md border cursor-pointer ${
                      priority === p 
                        ? 'bg-primary-50 border-primary-500 text-primary-700' 
                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <input
                      type="radio"
                      className="sr-only"
                      value={p}
                      checked={priority === p}
                      onChange={() => setPriority(p)}
                    />
                    <span className="text-sm font-medium">{p}</span>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Contact Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Your Email <span className="text-error-500">*</span>
              </label>
              <div className="mt-1">
                <input
                  type="email"
                  id="email"
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <p className="mt-2 text-sm text-gray-500">
                We'll use this to follow up on your feedback if needed.
              </p>
            </div>
            
            {/* Submit button */}
            <div className="flex justify-end">
              <button
                type="button"
                className="mr-3 inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                onClick={() => navigate(-1)}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                disabled={isSubmitting}
              >
                <Send className="h-4 w-4 mr-1" />
                {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FeedbackForm;