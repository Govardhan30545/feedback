import React, { useMemo } from 'react';
import { useFeedback } from '../context/FeedbackContext';
import { FeedbackStatus, FeedbackPriority, FeedbackSource } from '../types';
import { 
  BarChart, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  XCircle, 
  TrendingUp 
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const { feedbacks, isLoading } = useFeedback();
  
  // Calculate statistics
  const stats = useMemo(() => {
    const statusCount = {
      [FeedbackStatus.NEW]: 0,
      [FeedbackStatus.IN_PROGRESS]: 0,
      [FeedbackStatus.PLANNED]: 0,
      [FeedbackStatus.COMPLETED]: 0,
      [FeedbackStatus.REJECTED]: 0,
      [FeedbackStatus.URGENT]: 0,
    };
    
    const sourceCount = {
      [FeedbackSource.CUSTOMER]: 0,
      [FeedbackSource.EMPLOYEE]: 0,
      [FeedbackSource.SURVEY]: 0,
      [FeedbackSource.SOCIAL_MEDIA]: 0,
      [FeedbackSource.EMAIL]: 0,
      [FeedbackSource.OTHER]: 0,
    };
    
    const priorityCount = {
      [FeedbackPriority.CRITICAL]: 0,
      [FeedbackPriority.HIGH]: 0,
      [FeedbackPriority.MEDIUM]: 0,
      [FeedbackPriority.LOW]: 0,
    };
    
    const categories: Record<string, number> = {};
    
    feedbacks.forEach(feedback => {
      // Count by status
      statusCount[feedback.status]++;
      
      // Count by source
      sourceCount[feedback.source]++;
      
      // Count by priority
      priorityCount[feedback.priority]++;
      
      // Count by category
      const category = feedback.category;
      categories[category] = (categories[category] || 0) + 1;
    });
    
    return {
      totalFeedbacks: feedbacks.length,
      newFeedbacks: statusCount[FeedbackStatus.NEW],
      inProgressFeedbacks: statusCount[FeedbackStatus.IN_PROGRESS],
      urgentFeedbacks: statusCount[FeedbackStatus.URGENT],
      completedFeedbacks: statusCount[FeedbackStatus.COMPLETED],
      statusCount,
      sourceCount,
      priorityCount,
      categories,
    };
  }, [feedbacks]);
  
  // Loading state
  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="w-12 h-12 rounded-full bg-primary-200 mb-3"></div>
          <div className="h-4 w-24 bg-primary-100 rounded"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Summary stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Feedback"
          value={stats.totalFeedbacks}
          icon={<BarChart className="w-12 h-12 text-primary-200" />}
          trend="+12% from last month"
          color="bg-primary-50 text-primary-700"
        />
        <StatCard 
          title="New Feedback"
          value={stats.newFeedbacks}
          icon={<Clock className="w-12 h-12 text-blue-200" />}
          trend="+5 in the last 24 hours"
          color="bg-blue-50 text-blue-700"
        />
        <StatCard 
          title="Urgent Issues"
          value={stats.urgentFeedbacks}
          icon={<AlertTriangle className="w-12 h-12 text-error-200" />}
          trend="2 need immediate attention"
          color="bg-error-50 text-error-700"
        />
        <StatCard 
          title="Resolved"
          value={stats.completedFeedbacks}
          icon={<CheckCircle className="w-12 h-12 text-success-200" />}
          trend="+15% completion rate"
          color="bg-success-50 text-success-700"
        />
      </div>
      
      {/* Status distribution */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Feedback Status Distribution</h3>
          <select className="text-sm border rounded-md px-2 py-1">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>All time</option>
          </select>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <StatusCard 
            status="New"
            count={stats.statusCount[FeedbackStatus.NEW]}
            color="bg-blue-50 text-blue-700"
          />
          <StatusCard 
            status="In Progress"
            count={stats.statusCount[FeedbackStatus.IN_PROGRESS]}
            color="bg-purple-50 text-purple-700"
          />
          <StatusCard 
            status="Planned"
            count={stats.statusCount[FeedbackStatus.PLANNED]}
            color="bg-cyan-50 text-cyan-700"
          />
          <StatusCard 
            status="Completed"
            count={stats.statusCount[FeedbackStatus.COMPLETED]}
            color="bg-success-50 text-success-700"
          />
          <StatusCard 
            status="Rejected"
            count={stats.statusCount[FeedbackStatus.REJECTED]}
            color="bg-gray-50 text-gray-700"
          />
          <StatusCard 
            status="Urgent"
            count={stats.statusCount[FeedbackStatus.URGENT]}
            color="bg-error-50 text-error-700"
          />
        </div>
      </div>
      
      {/* Recent feedback */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Recent Feedback</h3>
          <button className="text-primary-600 text-sm font-medium hover:text-primary-700">
            View all
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {feedbacks.slice(0, 5).map((feedback) => (
                <tr key={feedback.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {feedback.title}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span 
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        feedback.status === FeedbackStatus.NEW ? 'bg-blue-100 text-blue-800' :
                        feedback.status === FeedbackStatus.IN_PROGRESS ? 'bg-purple-100 text-purple-800' :
                        feedback.status === FeedbackStatus.PLANNED ? 'bg-cyan-100 text-cyan-800' :
                        feedback.status === FeedbackStatus.COMPLETED ? 'bg-success-100 text-success-800' :
                        feedback.status === FeedbackStatus.REJECTED ? 'bg-gray-100 text-gray-800' :
                        'bg-error-100 text-error-800'
                      }`}
                    >
                      {feedback.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span 
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        feedback.priority === FeedbackPriority.CRITICAL ? 'bg-error-100 text-error-800' :
                        feedback.priority === FeedbackPriority.HIGH ? 'bg-orange-100 text-orange-800' :
                        feedback.priority === FeedbackPriority.MEDIUM ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}
                    >
                      {feedback.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {feedback.source}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {feedback.createdAt.toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Source and category distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Feedback by Source</h3>
          <div className="space-y-4">
            {Object.entries(stats.sourceCount)
              .filter(([_, count]) => count > 0)
              .sort(([_, countA], [__, countB]) => countB - countA)
              .map(([source, count]) => (
                <div key={source} className="flex items-center">
                  <div className="w-32 text-sm text-gray-600">{source}</div>
                  <div className="flex-1 ml-4">
                    <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary-500 rounded-full"
                        style={{ width: `${(count / stats.totalFeedbacks) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="ml-4 text-sm font-medium text-gray-900 w-8 text-right">
                    {count}
                  </div>
                </div>
              ))}
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Feedback by Category</h3>
          <div className="space-y-4">
            {Object.entries(stats.categories)
              .sort(([_, countA], [__, countB]) => countB - countA)
              .map(([category, count]) => (
                <div key={category} className="flex items-center">
                  <div className="w-32 text-sm text-gray-600">{category}</div>
                  <div className="flex-1 ml-4">
                    <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-secondary-500 rounded-full"
                        style={{ width: `${(count / stats.totalFeedbacks) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="ml-4 text-sm font-medium text-gray-900 w-8 text-right">
                    {count}
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Stat Card Component
interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  trend: string;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, trend, color }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 slide-up">
      <div className="flex justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
        </div>
        <div>{icon}</div>
      </div>
      <div className={`flex items-center mt-4 text-xs font-medium ${color}`}>
        <TrendingUp className="w-4 h-4 mr-1" />
        {trend}
      </div>
    </div>
  );
};

// Status Card Component
interface StatusCardProps {
  status: string;
  count: number;
  color: string;
}

const StatusCard: React.FC<StatusCardProps> = ({ status, count, color }) => {
  return (
    <div className={`rounded-lg p-4 ${color} slide-up`}>
      <p className="text-sm font-medium">{status}</p>
      <p className="text-2xl font-bold mt-1">{count}</p>
    </div>
  );
};

export default Dashboard;