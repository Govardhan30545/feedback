import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Feedback, FeedbackStatus, FeedbackSource, FeedbackPriority } from '../types';

// Define the shape of our context
interface FeedbackContextType {
  feedbacks: Feedback[];
  isLoading: boolean;
  addFeedback: (feedback: Omit<Feedback, 'id' | 'createdAt' | 'status'>) => void;
  updateFeedback: (id: string, updates: Partial<Feedback>) => void;
  deleteFeedback: (id: string) => void;
  getFeedbackById: (id: string) => Feedback | undefined;
  getFeedbacksByStatus: (status: FeedbackStatus) => Feedback[];
  getFeedbacksBySource: (source: FeedbackSource) => Feedback[];
  getFeedbacksByPriority: (priority: FeedbackPriority) => Feedback[];
}

// Create the context with a default value
const FeedbackContext = createContext<FeedbackContextType | undefined>(undefined);

// Sample data
const initialFeedbacks: Feedback[] = [
  {
    id: '1',
    title: 'Improve loading speed on product pages',
    description: 'The product pages are taking too long to load, especially on mobile devices.',
    source: FeedbackSource.CUSTOMER,
    status: FeedbackStatus.NEW,
    priority: FeedbackPriority.HIGH,
    category: 'Performance',
    createdAt: new Date('2025-05-15T10:30:00'),
    submitterEmail: 'john.smith@example.com',
    assignedTo: null,
    comments: []
  },
  {
    id: '2',
    title: 'Add dark mode to the application',
    description: 'We should consider adding a dark mode option for better user experience in low-light conditions.',
    source: FeedbackSource.EMPLOYEE,
    status: FeedbackStatus.IN_PROGRESS,
    priority: FeedbackPriority.MEDIUM,
    category: 'UI/UX',
    createdAt: new Date('2025-05-14T15:20:00'),
    submitterEmail: 'emma.jones@company.com',
    assignedTo: 'dev.team@company.com',
    comments: [
      {
        id: 'c1',
        text: 'Working on this now. Initial designs look promising.',
        author: 'dev.team@company.com',
        createdAt: new Date('2025-05-16T09:15:00')
      }
    ]
  },
  {
    id: '3',
    title: 'Issue with payment processing',
    description: 'Some users report that their payments are being declined even with valid card information.',
    source: FeedbackSource.CUSTOMER,
    status: FeedbackStatus.URGENT,
    priority: FeedbackPriority.CRITICAL,
    category: 'Payment',
    createdAt: new Date('2025-05-16T08:45:00'),
    submitterEmail: 'jane.doe@example.com',
    assignedTo: 'payment.team@company.com',
    comments: [
      {
        id: 'c2',
        text: 'Investigating this issue with our payment provider.',
        author: 'payment.team@company.com',
        createdAt: new Date('2025-05-16T09:30:00')
      }
    ]
  },
  {
    id: '4',
    title: 'Add more filters to search functionality',
    description: 'The current search filters are limited. Adding more options would improve user experience.',
    source: FeedbackSource.SURVEY,
    status: FeedbackStatus.PLANNED,
    priority: FeedbackPriority.LOW,
    category: 'Feature Request',
    createdAt: new Date('2025-05-10T14:20:00'),
    submitterEmail: 'survey@company.com',
    assignedTo: null,
    comments: []
  },
  {
    id: '5',
    title: 'Documentation needs updating',
    description: 'The API documentation is outdated and missing new endpoints.',
    source: FeedbackSource.EMPLOYEE,
    status: FeedbackStatus.IN_PROGRESS,
    priority: FeedbackPriority.MEDIUM,
    category: 'Documentation',
    createdAt: new Date('2025-05-12T11:15:00'),
    submitterEmail: 'developer@company.com',
    assignedTo: 'docs.team@company.com',
    comments: [
      {
        id: 'c3',
        text: 'Started updating the API documentation. Should be completed by next week.',
        author: 'docs.team@company.com',
        createdAt: new Date('2025-05-14T15:30:00')
      }
    ]
  }
];

export const FeedbackProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Simulate fetching data from an API
  useEffect(() => {
    const fetchData = () => {
      // In a real application, this would be an API call
      setTimeout(() => {
        setFeedbacks(initialFeedbacks);
        setIsLoading(false);
      }, 800);
    };
    
    fetchData();
  }, []);
  
  // Add new feedback
  const addFeedback = (feedback: Omit<Feedback, 'id' | 'createdAt' | 'status'>) => {
    const newFeedback: Feedback = {
      ...feedback,
      id: Date.now().toString(),
      createdAt: new Date(),
      status: FeedbackStatus.NEW,
      comments: []
    };
    
    setFeedbacks(prev => [newFeedback, ...prev]);
  };
  
  // Update existing feedback
  const updateFeedback = (id: string, updates: Partial<Feedback>) => {
    setFeedbacks(prev => 
      prev.map(feedback => 
        feedback.id === id ? { ...feedback, ...updates } : feedback
      )
    );
  };
  
  // Delete feedback
  const deleteFeedback = (id: string) => {
    setFeedbacks(prev => prev.filter(feedback => feedback.id !== id));
  };
  
  // Get feedback by ID
  const getFeedbackById = (id: string) => {
    return feedbacks.find(feedback => feedback.id === id);
  };
  
  // Get feedbacks by status
  const getFeedbacksByStatus = (status: FeedbackStatus) => {
    return feedbacks.filter(feedback => feedback.status === status);
  };
  
  // Get feedbacks by source
  const getFeedbacksBySource = (source: FeedbackSource) => {
    return feedbacks.filter(feedback => feedback.source === source);
  };
  
  // Get feedbacks by priority
  const getFeedbacksByPriority = (priority: FeedbackPriority) => {
    return feedbacks.filter(feedback => feedback.priority === priority);
  };
  
  return (
    <FeedbackContext.Provider
      value={{
        feedbacks,
        isLoading,
        addFeedback,
        updateFeedback,
        deleteFeedback,
        getFeedbackById,
        getFeedbacksByStatus,
        getFeedbacksBySource,
        getFeedbacksByPriority
      }}
    >
      {children}
    </FeedbackContext.Provider>
  );
};

// Custom hook to use the feedback context
export const useFeedback = () => {
  const context = useContext(FeedbackContext);
  if (context === undefined) {
    throw new Error('useFeedback must be used within a FeedbackProvider');
  }
  return context;
};