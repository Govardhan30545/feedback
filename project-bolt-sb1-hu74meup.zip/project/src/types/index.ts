// Feedback status enum
export enum FeedbackStatus {
  NEW = 'New',
  IN_PROGRESS = 'In Progress',
  PLANNED = 'Planned',
  COMPLETED = 'Completed',
  REJECTED = 'Rejected',
  URGENT = 'Urgent'
}

// Feedback source enum
export enum FeedbackSource {
  CUSTOMER = 'Customer',
  EMPLOYEE = 'Employee',
  SURVEY = 'Survey',
  SOCIAL_MEDIA = 'Social Media',
  EMAIL = 'Email',
  OTHER = 'Other'
}

// Feedback priority enum
export enum FeedbackPriority {
  CRITICAL = 'Critical',
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

// Comment interface
export interface Comment {
  id: string;
  text: string;
  author: string;
  createdAt: Date;
}

// Feedback interface
export interface Feedback {
  id: string;
  title: string;
  description: string;
  source: FeedbackSource;
  status: FeedbackStatus;
  priority: FeedbackPriority;
  category: string;
  createdAt: Date;
  submitterEmail: string;
  assignedTo: string | null;
  comments: Comment[];
}

// Analytics data interface
export interface AnalyticsData {
  totalFeedback: number;
  statusBreakdown: Record<FeedbackStatus, number>;
  sourceBreakdown: Record<FeedbackSource, number>;
  priorityBreakdown: Record<FeedbackPriority, number>;
  categoryBreakdown: Record<string, number>;
  trendData: {
    date: string;
    count: number;
  }[];
}